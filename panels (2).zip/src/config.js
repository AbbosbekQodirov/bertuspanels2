export const baseUrl = "https://iteachpython.uz";
